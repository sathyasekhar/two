package com.example.calldetails.service;

import java.util.List;

import com.example.calldetails.dto.CallDetailsDto;

public interface ICallDetailsService {
	List<CallDetailsDto>  readCallDetails(Long  phoneNumber);
}
