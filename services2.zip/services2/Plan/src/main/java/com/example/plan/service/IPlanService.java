package com.example.plan.service;

import java.util.List;

import com.example.plan.dto.PlanDTO;

public interface IPlanService {
	
	List<PlanDTO>  getAllPlans();
	
	PlanDTO   getSpecificPlan(String planId);

}
